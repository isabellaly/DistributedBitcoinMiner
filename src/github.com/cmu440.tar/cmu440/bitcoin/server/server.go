package main

import (
	"container/list"
	"encoding/json"
	"fmt"
	"github.com/cmu440/bitcoin"
	"github.com/cmu440/lsp"
	"os"
	"strconv"
)

/*
  Scheduler Implementation:
  The basic scheduling principle is that
  the server tries to assign jobs to a miner as often as possible,
  i.e. when a request comes, it tries to give it to a free miner,
       when a miner is free, it tries to find a pending request.
  Therefore, every miner tries to find jobs,
  and no miner is constantly working while others are free,
  so the work load is balanced.

  Four situations:
  1.When a miner join comes,
	the server goes through all miners in the map,
	finds each free miner and gives them jobs
	until there are no pending requests left.
  2.When a client request comes,
	the server goes through all miners in the map,
	finds each free miner and gives them jobs
	until there are no pending requests left.
  3.When a miner is lost,
	get the request that it was originally doing
	and assign the request to another free miner.
  4.When a miner finishes its job,
	the server goes through requestQueue,
	and finds a request that has not been processed yet,
	assigns it to the miner.
*/
func main() {
	const numArgs = 2
	if len(os.Args) != numArgs {
		fmt.Println("Usage: ./server <port>")
		return
	}
	port, _ := strconv.Atoi(os.Args[1])
	s, _ := lsp.NewServer(port, lsp.NewParams())
	miners := make(map[int]bool)
	clients := make(map[int]bool)
	requestsQueue := list.New()
	requestsClients := make(map[bitcoin.Message]int)
	minersRequests := make(map[int]bitcoin.Message)
	inProcessRequests := make(map[bitcoin.Message]bool)
	var message bitcoin.Message
	for {
		connID, messageBuf, readErr := s.Read()
		if readErr != nil {
			if _, ok := clients[connID]; ok {
				delete(clients, connID)
				for e := requestsQueue.Front(); e != nil; e = e.Next() {
					if clientID := requestsClients[e.Value.(bitcoin.Message)]; clientID == connID {
						delete(requestsClients, e.Value.(bitcoin.Message))
						requestsQueue.Remove(e)
					}
				}
			} else if _, ok := miners[connID]; ok {
				delete(miners, connID)
				resendRequest := minersRequests[connID]
				delete(minersRequests, connID)
				delete(inProcessRequests, resendRequest)
				/* Scheduler: when a miner is lost,
				get the request that it was originally doing
				and assign the request to another free miner */
				for minerID, occupied := range miners {
					if !occupied {
						resendRequestBuf, _ := json.Marshal(resendRequest)
						s.Write(minerID, resendRequestBuf)
						miners[minerID] = true
						minersRequests[minerID] = resendRequest
						inProcessRequests[resendRequest] = true
						break
					}
				}
			}
		} else {
			json.Unmarshal(messageBuf[:], &message)
			if message.Type == bitcoin.Join {
				miners[connID] = false
				/* Scheduler: when a miner join comes,
				the server goes through all miners in the map,
				finds each free miner and gives them jobs
				until there are no pending requests left */
				for minerID, occupied := range miners {
					if !occupied {
						for e := requestsQueue.Front(); e != nil; e = e.Next() {
							if _, ok := inProcessRequests[e.Value.(bitcoin.Message)]; !ok {
								requestBuf, _ := json.Marshal(e.Value.(bitcoin.Message))
								s.Write(minerID, requestBuf)
								miners[minerID] = true
								minersRequests[minerID] = e.Value.(bitcoin.Message)
								inProcessRequests[e.Value.(bitcoin.Message)] = true
								break
							}
						}
					}
				}
			} else if message.Type == bitcoin.Request {
				clients[connID] = true
				requestsClients[message] = connID
				requestsQueue.PushBack(message)
				/* Scheduler: when a client request comes,
				the server goes through all miners in the map,
				finds each free miner and gives them jobs
				until there are no pending requests left */
				for minerID, occupied := range miners {
					if !occupied {
						for e := requestsQueue.Front(); e != nil; e = e.Next() {
							if _, ok := inProcessRequests[e.Value.(bitcoin.Message)]; !ok {
								requestBuf, _ := json.Marshal(e.Value.(bitcoin.Message))
								s.Write(minerID, requestBuf)
								miners[minerID] = true
								minersRequests[minerID] = e.Value.(bitcoin.Message)
								inProcessRequests[e.Value.(bitcoin.Message)] = true
								break
							}
						}
					}
				}
			} else if message.Type == bitcoin.Result {
				request := minersRequests[connID]
				clientID := requestsClients[request]
				miners[connID] = false
				delete(inProcessRequests, request)
				delete(minersRequests, connID)
				delete(requestsClients, request)
				for e := requestsQueue.Front(); e != nil; e = e.Next() {
					if e.Value.(bitcoin.Message).Data == request.Data {
						requestsQueue.Remove(e)
						break
					}
				}
				if _, ok := clients[clientID]; ok {
					resultBuf, _ := json.Marshal(message)
					s.Write(clientID, resultBuf)
					delete(clients, clientID)
				}
				/* Scheduler: when a miner finishes its job,
				the server goes through requestQueue,
				and finds a request that has not been processed yet,
				assigns it to the miner */
				for e := requestsQueue.Front(); e != nil; e = e.Next() {
					if _, ok := inProcessRequests[e.Value.(bitcoin.Message)]; !ok {
						requestBuf, _ := json.Marshal(e.Value.(bitcoin.Message))
						s.Write(connID, requestBuf)
						miners[connID] = true
						minersRequests[connID] = e.Value.(bitcoin.Message)
						inProcessRequests[e.Value.(bitcoin.Message)] = true
						break
					}
				}
			}
		}
	}
}
