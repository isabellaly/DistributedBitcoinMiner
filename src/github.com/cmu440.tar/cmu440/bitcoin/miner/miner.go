package main

import (
	"encoding/json"
	"fmt"
	"github.com/cmu440/bitcoin"
	"github.com/cmu440/lsp"
	"os"
)

func main() {
	const numArgs = 2
	if len(os.Args) != numArgs {
		fmt.Println("Usage: ./miner <hostport>")
		return
	}
	hostport := os.Args[1]
	params := lsp.NewParams()
	m, _ := lsp.NewClient(hostport, params)
	join := bitcoin.NewJoin()
	joinBuf, _ := json.Marshal(join)
	joinWriteErr := m.Write(joinBuf)
	if joinWriteErr != nil {
		return
	}
	var request bitcoin.Message
	for {
		requestBuf, readErr := m.Read()
		if readErr != nil {
			m.Close()
			return
		}
		json.Unmarshal(requestBuf[:], &request)
		data := request.Data
		lower := request.Lower
		upper := request.Upper
		curr := bitcoin.Hash(data, lower)
		min := curr
		minNonce := lower
		for i := lower + 1; i <= upper; i++ {
			curr = bitcoin.Hash(data, i)
			if curr < min {
				min = curr
				minNonce = i
			}
		}
		result := bitcoin.NewResult(min, minNonce)
		resultBuf, _ := json.Marshal(result)
		resultWriteErr := m.Write(resultBuf)
		if resultWriteErr != nil {
			m.Close()
			return
		}
	}
}
